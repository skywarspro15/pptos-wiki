======================
        README
======================

Thank you for downloading Omnia!
Visit https://theomniaproject.weebly.com/ for more projects!

IMPORTANT:
~Please make sure to UNBLOCK the presentation file and enable Macros / ActiveX Controls when you are prompted to.
 Omnia will NOT work if you keep these functions disabled.
~You can UNBLOCK the presentation file by right clicking on it and choosing Properties > General Tab > Security > Check the UNBLOCK Check Mark.
~It is highly recommended to install the "Roboto" font family. They are included in this ZIP folder.

HOW TO INSTALL ROBOTO:
~Open the "Roboto" folder, included in the Omnia ZIP file.
~Select all files (except from the "LICENCE.txt" file) and right click.
~Choose "Install" and wait for a few seconds.
~Roboto is now available to use!

About Omnia™
Omnia™ is a PowerPoint® based Operating System Concept.
It is designed to resemble the appearance and the feel of a real Desktop Environment, simply by using PowerPoint® elements.

Omnia™ is Open Source, which means that anyone can view and use its code.
However, redistributing this PowerPoint™ presentation file as-is without permission is not allowed.

About LEMON UI™
Most of the elements used within this presentation are part of the LEMON UI™ developed by The Omnia Project™
The Icon pack used for the Applications is the “Elegant Themes Circle Icons” created by Elegant Themes.
All four of the default wallpapers included in Omnia™ OS1 belong to their respected creators.
Both sample images, featured in the “Photos” Application are properties of The Omnia Project™ 

System Information
Omnia™ OS1 Arcturus
Version 1.0.0
Build 1200



Based on Flopad Project Arcturus™, created by The Omnia Project™ in 2020.
The Omnia Project™, Omnia OS™ and Omnia Core™ logotypes are property of The Omnia Project™


======================
         FAQ
======================
 
-Can I use Omnia OS1 to develop my own projects?
-Yes! Omnia is Open Source, so you have direct access to its code. You can replicate or even copy Omnia's code into your own project, as long as you reference
"The Omnia Project" in your presentation's credits.

-Can I base my own project on the Omnia OS1 presentation file?
-No, neither copying elements from this presentation or redistributing the presentation file itself is allowed. However, you can DO all this with Flopad Arcturus, 
which is a simplified version of OMNIA OS1 and can be found on the official The Omnia Project Website.

-Will there be any updates for Omnia OS1?
-Perhaps. I am not commited to working on Omnia on a schedule, but there might be a follow up for the Omnia OS series in the near future.

-Are there any other projects from The Omnia Project I can try?
-Yes! In the official The Omnia Project Website you can find remastered versions of Flopad OS1 and Flopad OS2, as well as Flopad Arcturus.

-Is The Flopad Project = The Omnia Project?
-Yes. "Flopad" is just an older alias and mainly refers to older projects (pre 2019)
